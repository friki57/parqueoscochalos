#!/bin/bash

# codigo para actualizar el repositorio de github
#git config --global credential.helper store

git add .
git commit -am "github"
git push origin master
