module.exports = {
  get:
  {
    inicio: '/',
    normativas: '/Normativas',
    contacto: '/Contacto'
  },
  post:
  {

  },
  vista:
  {
    inicio: 'inicio',
    normativas: 'normativas',
    contacto: 'contacto'
  },
  ver:
  {
    inicio: 'nada',
    normativas: 'nada',
    contacto: 'nada'
  }
};
