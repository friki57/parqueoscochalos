$(document).ready(()=> {iniciarMapa();iniciarBD();});
//setInterval(intervalo,5000);
/*function intervalo()
{
  alternarDisponibilidad();
}*/
//var capa = 1;
// document.getElementById("ubica").addEventListener('click', ()=> {
//   ubicarcentro();
//   //capa=eliminarCapa(capa);
// });
