module.exports = {
  get:
  {
    
  },
  post:
  {
    Sensor: '/SensorRecibir/'
  },
  vista:
  {

  },
  ver:
  {
    Sensor: 'nada'
  }
};
