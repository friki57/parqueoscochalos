import React from "react"
import { render } from "react-dom"

import AdministrarMapas from "./../paginas/controlCalles.js"
import 'bootstrap/dist/css/bootstrap.min.css';
import './../css/general.css';
import './../css/cabecera.css';


render(<AdministrarMapas/>, document.getElementById("react"));
