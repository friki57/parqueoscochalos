

$(document).ready(()=> {
  //iniciarMapa();iniciarBD();

});
