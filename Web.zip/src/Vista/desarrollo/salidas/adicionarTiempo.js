import React from "react"
import { render } from "react-dom"

import AdicionarTiempo from "./../paginas/adicionarTiempo.js"
import './../css/general.css';
import './../css/cabecera.css';


render(<AdicionarTiempo/>, document.getElementById("react"));
