module.exports = {
    user: 'parqueoscochalos@gmail.com',
    pass: 'parqueos1'
  }
