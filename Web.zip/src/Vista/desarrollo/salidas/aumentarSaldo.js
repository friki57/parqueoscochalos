import React from "react"
import { render } from "react-dom"

import AdicionarSaldo from "./../paginas/aumentarSaldo.js"
import './../css/general.css';
import './../css/cabecera.css';


render(<AdicionarSaldo/>, document.getElementById("react"));
