
module.exports = (rutas, bd, ver, datos, http)=>
{
  // rutas.get(http.get.rutaDenunciaMovil.mapasInteractivos,ver[http.ver.rutaMapas.mapasInteractivos],(req,res)=>
  // {
  //   bd.cruds.crudDenuncia.leer((denuncia)=>
  //   {
  //     res.json(denuncia);
  //   });
  // });
  // rutas.get(http.get.rutaDenunciaMovil.mapasInteractivos,ver[http.ver.rutaMapas.mapasInteractivos],(req,res)=>
  // {
  //   bd.cruds.crudDenuncia.leer((denuncia)=>
  //   {
  //     res.json(denuncia);
  //   });
  // });
}
