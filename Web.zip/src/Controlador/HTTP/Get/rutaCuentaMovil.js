
module.exports = (rutas, bd, ver, datos, http)=>
{
  // rutas.get(http.get.rutaCuentaMovil.TodasCuentas,ver[http.ver.rutaCuentaMovil.TodasCuentas],(req,res)=>
  // {
  //   bd.cruds.Usuario.leer((usuarios)=>
  //   {
  //     res.json(usuarios);
  //   });
  // });
  // rutas.get(http.get.rutaCuentaMovil.MiCuenta,ver[http.ver.rutaCuentaMovil.MiCuenta],(req,res)=>
  // {
  //   var id = req.params.id;
  //   bd.cruds.Usuario.leerID(id,(Usuario)=>
  //   {
  //     res.json(Usuario);
  //   });
  // });
  // rutas.get(http.get.rutaCuentaMovil.mapasInteractivos,ver[http.ver.rutaMapas.mapasInteractivos],(req,res)=>
  // {
  //   var Cuenta = req.body;
  //   bd.cruds.Usuario.Ingresar(Cuenta,(Usuario)=>
  //   {
  //     res.send(200,"Exitoso");
  //   });
  // });
}
