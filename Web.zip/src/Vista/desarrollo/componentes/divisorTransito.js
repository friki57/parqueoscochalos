import React, { Component } from "react";

const amarillo = {
  background: '#E79A32',
  minHeight: '60px',
  minWidth: '62px'
}
const negro = {
  background: '#0B313F',
  minHeight: '60px',
  minWidth: '62px'
}
const inclinado =
{
/*  overflow: 'hidden',  */
  transform: 'skew(-15deg)'
}
class Cabecera extends Component
{
  render()
  {
    return (
      <div className = 'flex' style = {inclinado}>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
        <div style={amarillo}></div>
        <div style={negro}></div>
      </div>

    )
  }
}
export default Cabecera;
